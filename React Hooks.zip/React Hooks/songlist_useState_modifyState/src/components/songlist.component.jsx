import React,{useState} from 'react' 
import Song from './song.component'

//React Hooks use state
const Songlist = function(){
    const [songs,setSong] = useState({
          song:  [
            {id:1, name: 'despacito', duration:'2:50'},
            {id:2, name: 'my heart will go on', duration:'3:00'}
        ],
        selectedSong : ''    
    }
    )
    let listofSongs = songs.song.map((song1)=>{

        return <Song song={song1} key={song1.id} selectSong={(songId)=>selectSong(songId)}/> 
    })
    const selectSong = (songId)=> {
        let selectedSong = songs.song.filter((song)=> song.id === songId)

        setSong({
            ...songs,
        selectedSong : 'Selected Song '+selectedSong[0].name
        }
        );
    }

   return (
    <div>
        <div style={{width:'50%',display:'inline-block'}}>{listofSongs}</div>
        <div style={{width:'50%',display:'inline-block'}}>{songs.selectedSong}</div>
    </div>
   );     
}

export default Songlist