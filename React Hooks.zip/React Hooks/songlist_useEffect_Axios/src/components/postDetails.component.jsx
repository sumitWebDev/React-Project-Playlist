import React from 'react'

export default function PostDetails (props){
    return(
        <div>
            <p>{props.post.id}</p>
            <p>{props.post.title}</p>
        </div>
    )
}