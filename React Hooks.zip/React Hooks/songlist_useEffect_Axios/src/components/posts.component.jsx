import React,{Component, useEffect,useState} from 'react'
import axios from 'axios'
import PostDetails from './postDetails.component'


//Without hooks
// class Posts extends Component{
//     constructor(props){
//         super(props);
//         this.state = {posts:[]}
//     }
//      componentDidMount(){
//         axios
//         .get('https://jsonplaceholder.typicode.com/posts/')
//         .then((response)=> this.setState({posts: response.data}))
//      }  
     
//      render(){
//         let postListToBeDisplayed =  this.state.posts.map((post)=>
        
//            {return (<PostDetails key={post.id} post={post} />)}
//         )
//          return (
//              <div>{postListToBeDisplayed}</div>
//          )
//      }
// }

//With hooks
const Posts = function(){
    const [posts, setPost] = useState([]) 
    useEffect (() =>{
        axios
        .get('https://jsonplaceholder.typicode.com/posts/')
        .then((response)=>setPost(response.data))
    },[])
         let postListToBeDisplayed =  posts.map((post)=>
        
            {return (<PostDetails key={post.id} post={post} />)}
         )
    return(
        <div>
            {postListToBeDisplayed}
        </div>
    )
}

export default Posts