import React from "react"
import Songlist from "./components/songlist.component";
import ClickedCounter from "./components/clickedCounter.component"
import HoverCounter from "./components/hoverCounter.component"
import PostsWithoutHook from "./components/posts.component"
class App extends React.Component{
  render(){
    return(
      <div>
        {/* <Songlist />
        <ClickedCounter />
        <HoverCounter /> */}
        <PostsWithoutHook/>
      </div>
    );
  }
}

export default App;
