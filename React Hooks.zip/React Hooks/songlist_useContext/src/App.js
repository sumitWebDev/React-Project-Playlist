import React from "react"
import Songlist from "./components/songlist.component";
import ClickedCounter from "./components/clickedCounter.component"
import HoverCounter from "./components/hoverCounter.component"
import PostsWithoutHook from "./components/posts.component"

export var MostlyLovedContext = React.createContext();
class App extends React.Component{
  render(){
    return(
      <div>
        {/* <Songlist />
        <ClickedCounter />
        <HoverCounter /> */}
        <MostlyLovedContext.Provider value={'loved'}>
        <PostsWithoutHook/>
        </MostlyLovedContext.Provider>
      </div>
    );
  }
}


export default App;
