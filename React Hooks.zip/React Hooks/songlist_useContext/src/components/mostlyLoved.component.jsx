import React,{Component, useContext} from 'react'
import {MostlyLovedContext} from '../App'

//without useContext hooks
// class mostlyLoved extends Component{
//     render(){
//         return(
//             <MostlyLovedContext.Consumer>{
//                 (value) =>(
//                     <div><b>{value}</b></div>
//                 )
//             }
//             </MostlyLovedContext.Consumer>
//         )
//     }
// }

//with useContext hooks
function MostlyLoved(props){
    const mostlyLovedUseContext = useContext(MostlyLovedContext)
    return(
        <div><b>{mostlyLovedUseContext}</b></div>
    )
}

export default MostlyLoved