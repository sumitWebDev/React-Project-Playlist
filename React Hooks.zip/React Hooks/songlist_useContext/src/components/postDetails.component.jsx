import React from 'react'
import MostlyLoved from './mostlyLoved.component'

export default function PostDetails (props){
    return(
        <div>
            <p>{props.post.id}</p>
            <p>{props.post.title}</p>            
                <MostlyLoved />
        </div>
    )
}