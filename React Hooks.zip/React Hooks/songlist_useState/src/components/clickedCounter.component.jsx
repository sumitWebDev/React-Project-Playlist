import React, { Component } from 'react';
import PropTypes from 'prop-types';
//import UpdatedComponent from "./components/withCounter.component";
class ClickedCounter extends Component {
    constructor(props) {
        super(props);
        this.state={
            count: 0 
        }
    }
    increment = () => {
        this.setState({count : this.state.count + 1})
    }
    render() {
        return (
            <div>
                <button onClick = {() => this.increment()}>{this.props.name}Clicked {this.state.count} times</button>
            </div>
        );
    }
}



export default ClickedCounter;