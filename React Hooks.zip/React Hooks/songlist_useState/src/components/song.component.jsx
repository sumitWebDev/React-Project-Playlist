import React from 'react'


class Song extends React.Component{

    render(){
        return(
            <div>
                <p>ID : {this.props.song.id}</p>
                <p>Name : {this.props.song.name}</p>
                <p>Duration : {this.props.song.duration}</p>
                <button onClick = {()=>this.props.selectSong(this.props.song.id)}>Select</button>
            </div>
        )
    }
}

export default Song