import {Component, React} from 'react'

const UpdatedComponent = (OriginalComponent) =>{
    class NewComponent extends Component{
        render(){
            <OriginalComponent name = 'Sumit'/>
        }    
    return NewComponent
    }
}

export default UpdatedComponent