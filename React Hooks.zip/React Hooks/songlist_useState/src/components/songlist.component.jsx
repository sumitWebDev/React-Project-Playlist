import React,{useState} from 'react' 
import Song from './song.component'

//React Hooks use state
const Songlist = function(){
    const [songs,setSong] = useState(
        [
            {id:1, name: 'despacito', duration:'2:50'},
            {id:2, name: 'my heart will go on', duration:'3:00'}
        ]
    )
             let listofSongs = songs.map((song)=>{

             return <Song song={song} key={song.id} selectSong={(songId)=>this.selectSong(songId)}/> 
         })
   return (
    <div>
        <div style={{width:'50%',display:'inline-block'}}>{listofSongs}</div>
    </div>
   );     
}

export default Songlist