import React from 'react';
import ReactDOM from 'react-dom';

const Portal = ()=>{
    return(
        ReactDOM.createPortal(
            <h1>React Portals</h1>,              
              document.getElementById('react-portal')
            )
    )
}
export default Portal