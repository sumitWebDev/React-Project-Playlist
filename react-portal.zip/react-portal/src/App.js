import './App.css';
//import HighlighterWords from './components/forms.component';
// import Form from './components/forms.component'
import Portal from './components/react-portal';
function App() {
  return (
    <div className="App">
      {/* <Form /> */}
      {/* <HighlighterWords /> */}
      <Portal />
    </div>
  );
}

export default App;
