import React from 'react' 
import Song from './song.component'

class Songlist extends React.Component{

    constructor(props){
        super(props)
        this.state={
            songs : [
                {id:1, name: 'despacito', duration:'2:50'},
                {id:2, name: 'my heart will go on', duration:'3:00'}
            ],
            selectedSong :''
        }
    }
    selectSong = (event)=>{
        let selectedSong = this.state.songs.filter((song)=> song.id === event)
        this.setState({selectedSong: 'Selected Song :' + selectedSong[0].name});
    }
    render(){
        let listofSongs = this.state.songs.map((song)=>{

            return <Song song={song} key={song.id} selectSong={(songId)=>this.selectSong(songId)}/> 
        })
        let selectedSong = 'Selected Song'
        return (
            <div>
                <div style={{width:'50%',display:'inline-block'}}>{listofSongs}</div>
                <div style={{width:'50%',display:'inline-block'}}>{this.state.selectedSong}</div>
            </div>
        )
    }
}

export default Songlist