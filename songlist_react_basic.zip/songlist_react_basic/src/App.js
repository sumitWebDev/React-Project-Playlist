import React from "react"
import Songlist from "./components/songlist.component";

class App extends React.Component{
  render(){
    return(
      <div>
        <Songlist />
      </div>
    );
  }
}

export default App;
