import './App.css';
import Home from './components/home.component'
import About from './components/about.component'
import Navbar from './components/navbar.component';
import {Routes,Route} from 'react-router-dom'
import OrderSummary from './components/order-summary.component';
import NoMatch from './components/no-match.component';
import Product from './components/product.component';
import NewProducts from './components/new-products.component';
import FeaturedProducts from './components/featured-products.component';
import Users from './components/users.component';
import UserDetails from './components/user-details.component';
function App() {
  return (
    <div className="App">
      <Navbar/>
      <Routes>
        <Route path = '/' element={<Home/>} />
        <Route path = 'about' element={<About/>} />
        <Route path = 'order-summary' element={<OrderSummary/>} />
        <Route path = 'product' element={<Product/>} >
          <Route index element={<FeaturedProducts/>} />
          <Route path = 'new' element={<NewProducts/>} />
          <Route path = 'featured' element={<FeaturedProducts/>} />
        </Route>
        <Route path = 'user' element={<Users/>} />
        <Route path = 'user/:userId' element={<UserDetails />} />
        <Route path = '*' element={<NoMatch/>} />
      </Routes>
    </div>
  );
}

export default App;
