import React from 'react';
import { useParams } from 'react-router';

function UserDetails(props) {
    const {userId} = useParams() 
    return (
        <div>
            <h2>User Details {userId}</h2>
        </div>
    );
}

export default UserDetails;