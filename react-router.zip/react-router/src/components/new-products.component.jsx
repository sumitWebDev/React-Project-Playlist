import React from 'react';

function NewProducts(props) {
    return (
        <div>
            <h2>List of New Products</h2>
        </div>
    );
}

export default NewProducts;