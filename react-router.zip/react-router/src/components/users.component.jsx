import React from 'react';
import { useSearchParams } from 'react-router-dom';

function Users(props) {
    const [searchParams, setSearchParams] = useSearchParams();
    const isActiveFilter = searchParams.get('filter') === 'active'
    return (
        <div>
            <h3>User 1</h3>
            <h3>User 2</h3>
            <h3>User 3</h3>
            <button onClick = {()=>setSearchParams({filter : 'active'})}>Active Filter</button>
            <button onClick = {()=>setSearchParams({})} >Reset Filter</button>
            {
               isActiveFilter ? <h2>Active users</h2> : <h2>Showing all users</h2> 
            }
        </div>
    );
}

export default Users;