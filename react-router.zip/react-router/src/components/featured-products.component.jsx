import React from 'react';

function FeaturedProducts(props) {
    return (
        <div>
            <h2>List of Featured Products</h2>
        </div>
    );
}

export default FeaturedProducts;